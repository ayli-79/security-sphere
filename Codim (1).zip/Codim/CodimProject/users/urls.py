from django.urls import path
from .views import register_login, user_logout

urlpatterns = [
    path('auth/', register_login, name='register_login'),
    path('logout/', user_logout, name='logout'),
]
